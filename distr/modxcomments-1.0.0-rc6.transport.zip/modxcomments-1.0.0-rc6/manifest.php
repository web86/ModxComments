<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'ModxComments

Copyright (c) 2026 web86.
All rights reserved.

This development preview is distributed without an open-source license grant.
A final license should be selected before a public stable release.
',
    'readme' => '# ModxComments 1.0.0-rc6 — installation

## Compatibility

The same transport package supports:

- MODX Revolution 2.8.x
- MODX Revolution 3.0–3.2

## Building the universal transport

Build on MODX 2.8.x:

```bash
git checkout unified
git pull
php _build/build.transport.php
```

Output:

```text
modxcomments-1.0.0-rc6
```

Use the **same ZIP** on MODX 2 or MODX 3.0–3.2.

## Install / upgrade

1. Install the transport through Package Management.
2. Clear the MODX cache.
3. Add the cached snippet call:

```modx
[[ModxComments]]
```

Existing `modxcomments_comments` and `modxcomments_votes` data are preserved during upgrades.

### Important for local upgrade testing

Do not replace a transport ZIP with another build that has the same MODX package signature. MODX 2 caches the unpacked transport under `core/packages/<signature>/` and may continue installing the previously unpacked build even when the ZIP contents changed.

Every distributable build must use a new release/signature. This release is `modxcomments-1.0.0-rc6` specifically so installations that previously tested `1.0.0-rc1` receive the new files and resolver.

## Runtime compatibility

The package ships both models:

```text
MODX 2:
core/components/modxcomments/model/modxcomments/

MODX 3:
core/components/modxcomments/src/Model/
```

And both processor styles:

```text
MODX 2:
core/components/modxcomments/processors/

MODX 3:
core/components/modxcomments/src/Processors/
```

The public and manager connectors choose the correct implementation automatically.

## Manager login on the frontend

When no normal web-context login exists, a valid manager session is accepted for frontend commenting only when the manager user is sudo or belongs to Administrator.

The comment is saved with that MODX user ID and current profile information.

## Frontend Admin badge

Comments belonging to a current sudo/Administrator user are rendered with:

```text
★ Admin  Full Name
```

The displayed name comes from the user\'s current profile fullname, falling back to username.

## Settings

```text
modxcomments.allow_guests = 1
modxcomments.max_depth = 5
modxcomments.max_length = 5000
modxcomments.edit_time = 900
modxcomments.rate_limit_count = 5
modxcomments.rate_limit_window = 60
modxcomments.guest_status = published
modxcomments.user_status = published
modxcomments.threads_per_page = 20
modxcomments.captcha_enabled = 0
modxcomments.captcha_provider = turnstile
modxcomments.captcha_guests_only = 1
modxcomments.notify_admin = 0
modxcomments.notify_replies = 0
```

## CAPTCHA providers

The comment form supports four providers without changing the `[[ModxComments]]` call:

- `none` — no CAPTCHA
- `turnstile` — Cloudflare Turnstile
- `hcaptcha` — hCaptcha
- `recaptcha` — Google reCAPTCHA v2 or v3
- `yandex` — Yandex SmartCaptcha

Enable CAPTCHA with `modxcomments.captcha_enabled=1`, choose the provider in `modxcomments.captcha_provider`, and configure that provider\'s keys.

For Google reCAPTCHA, set `modxcomments.recaptcha_version` to `v2` or `v3`. With v3, `modxcomments.recaptcha_min_score` controls the minimum accepted score and defaults to `0.5`.

`modxcomments.captcha_guests_only=1` requires CAPTCHA only for unauthenticated visitors.

Existing installations that used the old Turnstile enable/guests-only switches are migrated automatically to the generic CAPTCHA settings during upgrade.

## Email templates

Editable Chunks:

- `ModxCommentsEmailAdminSubject`
- `ModxCommentsEmailAdminBody`
- `ModxCommentsEmailReplySubject`
- `ModxCommentsEmailReplyBody`

User changes to these Chunks are preserved during upgrades.

## Uninstall

Component registration, settings and menu are removed. Comment tables/data are intentionally preserved.


## Security notes

`modxcomments.resource_signing_key` is generated automatically and is used only to sign the resource/context rendered by the snippet. Do not publish or routinely rotate it; changing it invalidates cached comment widgets until those pages are regenerated.

The manager comments CMP is intentionally limited to sudo users and members of the Administrator group in this release candidate.

After upgrading from an earlier beta, clear the MODX resource cache so pages contain the new signed resource token.
',
    'changelog' => '# Changelog

## 1.0.0-rc6 — Pluggable CAPTCHA providers
- Add a generic CAPTCHA provider layer shared by MODX 2 and MODX 3.
- Support Cloudflare Turnstile, hCaptcha, Google reCAPTCHA v2/v3, Yandex SmartCaptcha, and an explicit none provider.
- Add generic CAPTCHA enable/provider/guests-only settings and provider-specific credentials.
- Verify every CAPTCHA token server-side over TLS using the provider\'s official verification endpoint.
- Validate Google reCAPTCHA v3 action and configurable minimum score; request v3 tokens at submit time.
- Migrate existing Turnstile enable/guests-only settings to the new generic settings and remove the obsolete duplicate toggles.
- Keep the `[[ModxComments]]` call unchanged.
- Use a new transport signature so older MODX installations cannot reuse an unpacked rc5 package.

## 1.0.0-rc5 — Permanent admin deletion
- Add a manager-only permanent delete action for comments.
- Permanently deleting a comment also removes all descendant replies and related votes to avoid orphaned records.
- Keep the existing soft-delete action unchanged for normal moderation.
- Add MODX 2 and MODX 3 hard-delete processors and localized confirmation messages.
- Use a new transport signature so older MODX installations cannot reuse an unpacked rc4 package.

## 1.0.0-rc4 — MODX 2 manager routing fix
- Detect MODX 2/3 from the installed version in the manager connector instead of autoloaded class availability.
- Apply the same deterministic version routing to the namespace bootstrap.
- Add a clear MODX 2 processor-path diagnostic when the manager connector cannot dispatch a processor.
- Use a new transport signature so MODX 2 cannot reuse an unpacked rc3 package.

## 1.0.0-rc3 — Legacy MODX 2 upgrade repair
- Detect MODX 2/3 from `core/docs/version.inc.php` instead of autoloaded class availability.
- Remove the install resolver\'s silent class-mismatch exit so legacy MODX 2 installs cannot skip settings/menu creation.
- Use deterministic version routing in the runtime service, snippet fallback, and manager controller.
- Log successful completion of the install resolver with the detected MODX version.
- Use a new transport signature so MODX 2 cannot reuse an unpacked rc2 package.

## 1.0.0-rc2 — Upgrade reliability
- Use a new transport signature so MODX 2 cannot reuse an unpacked `1.0.0-rc1` package after the ZIP has changed.
- Register both namespace core and assets paths in the transport.
- Fail installation when required namespace, settings, manager menu, or events cannot be persisted.
- Verify the generated resource-signing key and manager menu after installation.
- Repair a missing resource-signing key from the snippet and fail closed if it cannot be persisted.
- Initialize frontend localization before protected comment-list requests.

## 1.0.0-rc1 — Security hardening
- Restrict the manager CMP and moderation processors to sudo/Administrator users.
- Validate MODX manager `HTTP_MODAUTH` in the custom manager connector.
- Require POST for manager status/delete mutations.
- Add a generated HMAC resource-signing key and bind public comment operations to resources where the snippet is rendered.
- Reject the public `mgr` context and unpublished/deleted/non-viewable resources.
- Add a 64 KiB JSON request-body limit.
- Add HttpOnly + SameSite=Lax to guest ownership/vote cookies and Secure when HTTPS is active.
- Neutralize untrusted MODX tag delimiters before processing email notification Chunks.
- Strip CR/LF from notification subject and From-name header values.
- Hide unexpected public exception details behind `server_error` while logging details server-side.
- Escape resource titles in the manager grid.
- Add PHP 7.4 and JavaScript syntax CI plus manual workflow dispatch.
- Validate signed resource routing before `ModxCommentsBeforeCommentCreate` and prevent hooks from redirecting resource/context.
- Explicitly validate notification recipient addresses and Turnstile TLS certificates.
- Add SECURITY.md and update the public API security contract.

## 1.0.0-beta2 — Unified MODX 2.8 + MODX 3.0–3.2
- Restore the entire legacy flat processor layer from the tested MODX 2 branch.
- Fix MODX 2 manager CMP error caused by MODX 3 processor base classes leaking into `core/components/modxcomments/processors/`.
- Keep MODX 3 namespaced processors isolated under `src/Processors/`.
- Public and manager connectors continue selecting the appropriate processor layer at runtime.

## 1.0.0-beta1 — Unified MODX 2.8 + MODX 3.0–3.2
- Combine the tested MODX 2 and MODX 3.0–3.2 runtime lines into one transport package.
- Add runtime service routing between MODX 2 and MODX 3 implementations.
- Add dual public connector dispatch for flat MODX 2 processors and FQCN MODX 3 processors.
- Add dual manager connector dispatch while keeping one manager JavaScript bundle.
- Add a runtime-compatible manager controller base.
- Commit both xPDO 2 and xPDO 3 model metadata so normal package builds do not generate runtime model PHP.
- Add a version-neutral installer resolver for namespace, settings, menu, tables, migrations and events.
- Recognize valid manager sudo/Administrator sessions on the frontend for both MODX 2 and MODX 3.
- Mark admin-authored frontend comments with a `★ Admin` badge.
- Resolve the displayed admin author name from the current MODX profile fullname, falling back to username.
- Keep the same comment/vote tables across both MODX versions.
- Universal transport is built on MODX 2.8 and installed unchanged on either supported MODX line.

## 0.3.0-beta8 — MODX 3
- Recognize an authenticated MODX manager administrator on the frontend when there is no separate web-context login.
- Use the valid `mgr` session only for sudo users or members of the Administrator group.
- Preserve normal web-context authentication as the first priority.
- Expose the authentication source internally so frontend/admin identity remains explicit.

## 0.3.0-beta7 — MODX 3
- Fix manager grid response format.
- Avoid double-encoding JSON returned by GetListProcessor::outputArray().
- Pass pre-encoded list responses through unchanged; encode array responses normally.

## 0.3.0-beta6 — MODX 3
- Fix manager connector response serialization for MODX 3.
- Replace removed ProcessorResponse::toJSON() with getResponse() + json_encode().
- Confirms manager processor dispatch and xPDO model loading now reach successful processor execution.

## 0.3.0-beta5 — MODX 3
- Commit the xPDO 3 model classes and metadata into the repository instead of generating them during normal transport builds.
- Remove parseSchema() from the regular transport build path.
- Add exact PHP file and line information to manager connector fatal diagnostics.
- Keep direct manager processor dispatch from beta4.

## 0.3.0-beta4 — MODX 3
- Replace manager connector request handling with a direct, explicit processor dispatcher.
- Whitelist manager actions and map them to concrete processor files/classes.
- Explicitly register and verify the MODX 3 model before processor execution.
- Catch all PHP Throwables in the manager connector and return/log the exact error instead of a silent HTTP 500.
- Keep compatibility aliases for both legacy manager action names and FQCN actions.

## 0.3.0-beta3 — MODX 3
- Move MODX 3 runtime processors to namespaced classes under `src/Processors`.
- Make the manager grid call processor FQCNs, matching the standard MODX 3 Extra pattern.
- Map the public `web/comment/*` API actions internally to FQCN processors.
- Register the ModxComments namespace package in both public and manager connectors before processor dispatch.
- Clean up the manager grid configuration and restore `viewConfig` to the correct level.
- Keep the corrected xPDO 3 schema from beta2.

## 0.3.0-beta2 — MODX 3
- Fix xPDO 3 schema namespaces to use XML single backslashes, matching MODX 3/xPDO 3 conventions.
- Regenerate the MODX 3 model under the correct `ModxComments\\Model` namespace.
- Add manager-grid diagnostics when the generated `Comment` model cannot be loaded.

## 0.3.0-beta1 — MODX 3
- Create a dedicated MODX 3 branch from the MODX 2 beta14 feature set.
- Bootstrap through MODX 3 vendor autoload and `MODX\\Revolution\\modX::getInstance()`.
- Convert the xPDO schema to xPDO 3 namespaced model classes.
- Generate `ModxComments\\Model\\Comment` and `Vote` under `src/`.
- Convert public and manager processors to MODX 3 namespaced processor bases.
- Convert the manager controller and installer resolver to MODX 3 class names.
- Add namespace bootstrap for the xPDO 3 model.
- Build a separate `modxcomments-0.3.0-beta1` transport requiring MODX 3.
- Remove the MODX 2 deprecated manager fallback from this branch.
- Keep beta14 autoscroll and localized relative timestamps.

## 0.2.0-beta14
- Smooth-scroll to a newly submitted comment after the list refreshes.
- Briefly highlight the submitted comment after autoscroll.
- Render comment timestamps as localized relative time using Intl.RelativeTimeFormat.
- Keep the exact server timestamp in the time element tooltip/datetime attribute.

## 0.2.0-beta13
- Localize the entire frontend through the `modxcomments:frontend` lexicon (EN/RU).
- Add guest ownership via a long-lived HttpOnly browser token; only its hash is stored with new guest comments.
- Allow new guest comments to be edited/deleted within `modxcomments.edit_time`.
- Add root-thread pagination with configurable `modxcomments.threads_per_page`.
- Add live published-comment count to the frontend heading and `GET web/comment/count`.
- Add editable MODX Chunks for administrator and reply email subjects/bodies.
- Preserve user-edited email Chunks on package upgrades.
- Add `ModxCommentsBeforeCommentCreate`, `ModxCommentsOnCommentPublish` and `ModxCommentsOnCommentVote` events.
- Emit publish events only when a comment actually transitions to published.
- Preserve current-tab pending previews across frontend rerenders.

## 0.2.0-beta12
- Fix the transport file-resolver targets for clean installs.
- Core source now resolves into `MODX_CORE_PATH/components/`, avoiding an accidental nested `modxcomments/modxcomments/` directory.
- Assets source now resolves into `MODX_ASSETS_PATH/components/` for the same reason.
- Add installer diagnostics for missing controller/model/frontend paths after extraction.

## 0.2.0-beta11
- Add a manager controller under controllers/default/index.class.php, which MODX 2.8 checks before controllers/index.class.php.
- Add a legacy index.php compatibility fallback for installations that unexpectedly use modManagerControllerDeprecated.
- Keep namespace routing (namespace=modxcomments, action=index) as the primary manager route.

## 0.2.0-beta10
- Fix clean-install warning when the xPDO model directory is not yet available during the PHP resolver.
- Create and migrate ModxComments tables directly in the installer resolver.
- Keep xPDO model loading for normal runtime after package files are installed.

## 0.2.0-beta8
- Fix transport package metadata so Instructions/Readme, License and Changelog can never become boolean false.
- Add embedded fallback text when metadata files are missing or unreadable during build.
- Structure the manager comments grid as visible reply threads.
- Indent replies by nesting depth and show the parent author + excerpt.
- Visually separate root comments from replies.
- Detect administrator-authored comments using MODX sudo or Administrator group membership.
- Highlight administrator replies with a badge and row styling.

## 0.2.0-beta7
- Fill MODX transport-package Instructions/Readme, License and Changelog metadata.
- Add a dedicated installation/upgrade instruction document.
- Show a newly submitted pending comment as a translucent, current-tab-only preview.
- Add optional administrator email notifications for all new comments.
- Add optional reply notifications when a reply becomes published.
- Delay reply notification until moderation publishes a pending reply.
- Track reply notification delivery to avoid duplicate emails.
- Add localized system-setting names/descriptions for notification options.

## 0.2.0-beta6
- Add localized names and clear descriptions for every ModxComments system setting.
- Document and clarify `guest_status=pending` / `user_status=pending` moderation defaults.
- Add visible comment numbers and permalinks such as `#comment-123`.
- Highlight a comment when opened by its permalink.
- Migrate ModxComments tables and public API connection to `utf8mb4` for 4-byte emoji.
- Expand the link toolbar to separate link text and URL fields.
- Add safe labeled-link syntax `[text](https://url)` while keeping arbitrary HTML escaped.

## 0.2.0-beta5
- Require guest email on both frontend and server.
- Add a hidden honeypot anti-spam field.
- Add reversible 👍 / 👎 voting with per-user/browser identity.
- Add editor toolbar with URL insertion and emoji picker.
- Add reply quote previews in the composer and rendered reply cards.
- Add a vote table created automatically during package upgrade.
- Clarify that edit_time applies only to authenticated comment owners.

## 0.2.0-beta4
- Replace browser prompt/confirm flows with inline edit and delete states.
- Add loading, busy, empty, success/error, reply and character-count states on the frontend.
- Add a neutral responsive frontend skin based on CSS variables.
- Improve manager grid readability with status badges, email links, clear search and status feedback.
- Improve EN/RU manager copy and action discoverability.

## 0.2.0-beta3
- Load manager lexicon through `getLanguageTopics()`, so ExtJS `_()` labels are populated.
- Add Email column to the manager comments grid.
- Add explicit English and Russian labels for toolbar filters and row actions.
- Explicitly strip PHP opening/closing tags from snippet source during transport build.
- Keep the beta2 routing/category fixes.

## 0.2.0-beta2
- Fix transport category key: `modCategory.category` instead of invalid `category_name`.
- Replace deprecated manager `modAction` routing with namespace + action-name routing.
- Repair the existing Comments menu entry when installing over the first beta.
- Initialize manager JS namespaces before defining grid/panel classes.
- Generate xPDO model classes automatically while building the transport package.

## 0.2.0-beta
- Authenticated author edit within a configurable time window.
- Soft delete without breaking reply trees.
- Optional Cloudflare Turnstile integration.
- Basic manager moderation CMP.
- Transport-package build and installer resolver.
- MODX system settings and custom create/update/delete events.
- Preserves the AJAX/cache-independent architecture from v0.1.

## 0.1.0
- Initial AJAX-first MODX 2.x scaffold.
- Threaded comments, guest/user posting, CSRF, plain-text rendering and rate limiting.
',
    'requires' => 
    array (
      'php' => '>=7.4.0',
      'modx' => '>=2.8.0,<3.3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5278a78ee6d27669a6495e2ff8f2c317',
      'native_key' => 'modxcomments',
      'filename' => 'modNamespace/3d74748614a5e0ccf6ba29d462d2f3bd.vehicle',
      'namespace' => 'modxcomments',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd14511ef8263d501de6be508cf518cdb',
      'native_key' => NULL,
      'filename' => 'modCategory/9c0d0dd20618a88cacfdb94e32a4350b.vehicle',
      'namespace' => 'modxcomments',
    ),
  ),
);